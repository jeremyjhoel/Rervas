-- MySQL dump 10.13  Distrib 8.0.33, for Linux (x86_64)
--
-- Host: localhost    Database: Reserva
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Reservar_asientos`
--

DROP TABLE IF EXISTS `Reservar_asientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reservar_asientos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `numero` int DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  `bus_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Reservar_asientos_bus_id_6818d913_fk_Reservar_bus_id` (`bus_id`),
  CONSTRAINT `Reservar_asientos_bus_id_6818d913_fk_Reservar_bus_id` FOREIGN KEY (`bus_id`) REFERENCES `Reservar_bus` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reservar_asientos`
--

LOCK TABLES `Reservar_asientos` WRITE;
/*!40000 ALTER TABLE `Reservar_asientos` DISABLE KEYS */;
INSERT INTO `Reservar_asientos` VALUES (7,NULL,0,1);
/*!40000 ALTER TABLE `Reservar_asientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Reservar_bus`
--

DROP TABLE IF EXISTS `Reservar_bus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reservar_bus` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `patente` varchar(50) NOT NULL,
  `cantidadAsientos` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reservar_bus`
--

LOCK TABLES `Reservar_bus` WRITE;
/*!40000 ALTER TABLE `Reservar_bus` DISABLE KEYS */;
INSERT INTO `Reservar_bus` VALUES (1,'patente1?',30);
/*!40000 ALTER TABLE `Reservar_bus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Reservar_cliente`
--

DROP TABLE IF EXISTS `Reservar_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reservar_cliente` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `rut` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reservar_cliente`
--

LOCK TABLES `Reservar_cliente` WRITE;
/*!40000 ALTER TABLE `Reservar_cliente` DISABLE KEYS */;
INSERT INTO `Reservar_cliente` VALUES (2,'sdasda','asadasd','asdasdasda@gmail.com','a','a');
/*!40000 ALTER TABLE `Reservar_cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Reservar_disponibilidad`
--

DROP TABLE IF EXISTS `Reservar_disponibilidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reservar_disponibilidad` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `horario` time(6) NOT NULL,
  `fecha` date NOT NULL,
  `disponible` tinyint(1) NOT NULL,
  `asiento_id` bigint NOT NULL,
  `bus_id` bigint NOT NULL,
  `ruta_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Reservar_disponibili_asiento_id_f7868907_fk_Reservar_` (`asiento_id`),
  KEY `Reservar_disponibilidad_bus_id_d3f46293_fk_Reservar_bus_id` (`bus_id`),
  KEY `Reservar_disponibilidad_ruta_id_f170c494_fk_Reservar_ruta_id` (`ruta_id`),
  CONSTRAINT `Reservar_disponibili_asiento_id_f7868907_fk_Reservar_` FOREIGN KEY (`asiento_id`) REFERENCES `Reservar_asientos` (`id`),
  CONSTRAINT `Reservar_disponibilidad_bus_id_d3f46293_fk_Reservar_bus_id` FOREIGN KEY (`bus_id`) REFERENCES `Reservar_bus` (`id`),
  CONSTRAINT `Reservar_disponibilidad_ruta_id_f170c494_fk_Reservar_ruta_id` FOREIGN KEY (`ruta_id`) REFERENCES `Reservar_ruta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reservar_disponibilidad`
--

LOCK TABLES `Reservar_disponibilidad` WRITE;
/*!40000 ALTER TABLE `Reservar_disponibilidad` DISABLE KEYS */;
/*!40000 ALTER TABLE `Reservar_disponibilidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Reservar_reserva`
--

DROP TABLE IF EXISTS `Reservar_reserva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reservar_reserva` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fechaReserva` datetime(6) NOT NULL,
  `cantidadPasajes` int NOT NULL,
  `asiento_id` bigint NOT NULL,
  `bus_id` bigint NOT NULL,
  `cliente_id` bigint NOT NULL,
  `ruta_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Reservar_reserva_asiento_id_04ed63d4_fk_Reservar_asientos_id` (`asiento_id`),
  KEY `Reservar_reserva_bus_id_47e8f4c3_fk_Reservar_bus_id` (`bus_id`),
  KEY `Reservar_reserva_cliente_id_4f10449d_fk_Reservar_cliente_id` (`cliente_id`),
  KEY `Reservar_reserva_ruta_id_441c67ba_fk_Reservar_ruta_id` (`ruta_id`),
  CONSTRAINT `Reservar_reserva_asiento_id_04ed63d4_fk_Reservar_asientos_id` FOREIGN KEY (`asiento_id`) REFERENCES `Reservar_asientos` (`id`),
  CONSTRAINT `Reservar_reserva_bus_id_47e8f4c3_fk_Reservar_bus_id` FOREIGN KEY (`bus_id`) REFERENCES `Reservar_bus` (`id`),
  CONSTRAINT `Reservar_reserva_cliente_id_4f10449d_fk_Reservar_cliente_id` FOREIGN KEY (`cliente_id`) REFERENCES `Reservar_cliente` (`id`),
  CONSTRAINT `Reservar_reserva_ruta_id_441c67ba_fk_Reservar_ruta_id` FOREIGN KEY (`ruta_id`) REFERENCES `Reservar_ruta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reservar_reserva`
--

LOCK TABLES `Reservar_reserva` WRITE;
/*!40000 ALTER TABLE `Reservar_reserva` DISABLE KEYS */;
/*!40000 ALTER TABLE `Reservar_reserva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Reservar_ruta`
--

DROP TABLE IF EXISTS `Reservar_ruta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reservar_ruta` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `origen` varchar(100) NOT NULL,
  `destino` varchar(100) NOT NULL,
  `tiempoEstimado` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reservar_ruta`
--

LOCK TABLES `Reservar_ruta` WRITE;
/*!40000 ALTER TABLE `Reservar_ruta` DISABLE KEYS */;
/*!40000 ALTER TABLE `Reservar_ruta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add cliente',7,'add_cliente'),(26,'Can change cliente',7,'change_cliente'),(27,'Can delete cliente',7,'delete_cliente'),(28,'Can view cliente',7,'view_cliente'),(29,'Can add bus',8,'add_bus'),(30,'Can change bus',8,'change_bus'),(31,'Can delete bus',8,'delete_bus'),(32,'Can view bus',8,'view_bus'),(33,'Can add ruta',9,'add_ruta'),(34,'Can change ruta',9,'change_ruta'),(35,'Can delete ruta',9,'delete_ruta'),(36,'Can view ruta',9,'view_ruta'),(37,'Can add asientos',10,'add_asientos'),(38,'Can change asientos',10,'change_asientos'),(39,'Can delete asientos',10,'delete_asientos'),(40,'Can view asientos',10,'view_asientos'),(41,'Can add reserva',11,'add_reserva'),(42,'Can change reserva',11,'change_reserva'),(43,'Can delete reserva',11,'delete_reserva'),(44,'Can view reserva',11,'view_reserva'),(45,'Can add disponibilidad',12,'add_disponibilidad'),(46,'Can change disponibilidad',12,'change_disponibilidad'),(47,'Can delete disponibilidad',12,'delete_disponibilidad'),(48,'Can view disponibilidad',12,'view_disponibilidad');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$320000$ynmwmWUtWZkS5qjQKoaV84$Wz9NthMp+3tq3D4REgLnN/5rnwyaHJWq5wBWI0hpWPI=','2023-06-02 00:47:58.154100',1,'moranciox','','','eduardoignacio.moran@gmail.com',1,1,'2023-06-02 00:47:30.628687');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2023-06-02 00:56:46.423380','1','Cliente object (1)',1,'[{\"added\": {}}]',7,1),(2,'2023-06-02 01:03:48.396527','1','Cliente object (1)',3,'',7,1),(3,'2023-06-02 01:07:04.862433','2','Cliente object (2)',1,'[{\"added\": {}}]',7,1),(4,'2023-06-02 20:13:45.891481','1','30',1,'[{\"added\": {}}]',8,1),(5,'2023-06-02 20:15:08.626382','1','patente1?',2,'[{\"changed\": {\"fields\": [\"Patente\"]}}]',8,1),(6,'2023-06-02 20:29:19.858294','7','Asientos object (7)',1,'[{\"added\": {}}]',10,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(10,'Reservar','asientos'),(8,'Reservar','bus'),(7,'Reservar','cliente'),(12,'Reservar','disponibilidad'),(11,'Reservar','reserva'),(9,'Reservar','ruta'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2023-06-02 00:39:42.894023'),(2,'auth','0001_initial','2023-06-02 00:39:59.072389'),(3,'admin','0001_initial','2023-06-02 00:40:04.889100'),(4,'admin','0002_logentry_remove_auto_add','2023-06-02 00:40:04.966940'),(5,'admin','0003_logentry_add_action_flag_choices','2023-06-02 00:40:05.163657'),(6,'contenttypes','0002_remove_content_type_name','2023-06-02 00:40:07.593471'),(7,'auth','0002_alter_permission_name_max_length','2023-06-02 00:40:10.117928'),(8,'auth','0003_alter_user_email_max_length','2023-06-02 00:40:10.561054'),(9,'auth','0004_alter_user_username_opts','2023-06-02 00:40:10.671403'),(10,'auth','0005_alter_user_last_login_null','2023-06-02 00:40:14.545304'),(11,'auth','0006_require_contenttypes_0002','2023-06-02 00:40:14.726051'),(12,'auth','0007_alter_validators_add_error_messages','2023-06-02 00:40:14.877647'),(13,'auth','0008_alter_user_username_max_length','2023-06-02 00:40:16.372565'),(14,'auth','0009_alter_user_last_name_max_length','2023-06-02 00:40:18.088092'),(15,'auth','0010_alter_group_name_max_length','2023-06-02 00:40:18.380942'),(16,'auth','0011_update_proxy_permissions','2023-06-02 00:40:18.487907'),(17,'auth','0012_alter_user_first_name_max_length','2023-06-02 00:40:20.214546'),(18,'sessions','0001_initial','2023-06-02 00:40:22.166041'),(19,'Reservar','0001_initial','2023-06-02 00:55:56.646248'),(20,'Reservar','0002_asientos_bus_ruta_reserva_disponibilidad_and_more','2023-06-02 02:31:04.792836'),(21,'Reservar','0003_alter_asientos_numero','2023-06-02 20:26:30.328661');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('4xx4wojlttppufb8flvqhr87xvwv538q','.eJxVjEEOgjAQRe_StWmmLR3QpXvOQIb-QVBTEgor492VhIVu_3vvv0wn2zp2W9Glm2AuxpnT79ZLemjeAe6Sb7NNc16Xqbe7Yg9abDtDn9fD_TsYpYzfOg0OdfDRC9WslVJQXzEkcGAXh9SAInsdGjn3rgICFIwmolYiITLvD94BN_E:1q4sxS:Lfxy0mp8Y3csIvJBTCNbxCxBOQjscbicLUhcwrkqId8','2023-06-16 00:47:58.288738');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-02 17:32:21
